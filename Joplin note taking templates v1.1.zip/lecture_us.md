# Lecture Title
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Lecture Topics:
- What is this lecture about.

## Lecture Preparation:
- What do you need to prepare before attending this lecture.

## Important Points:
- Most important points of this lecture.

## Lecture Topic: 
- Take lecture notes here.

## Summary
- Summarize the main points of this Lecture.

## Questions
- Questions in response to this lecture.
 
## To study
- What to study as a result of this Lecture.
