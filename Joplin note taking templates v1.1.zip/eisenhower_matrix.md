# Eisenhower Matrix
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Use the matrix below to organize your tasks in order of priorities
| **DO IT NOW** - DO FIRST <br /> Urgent & Important | **SCHEDULE** - DO LATER <br /> Important but Not Urgent |
| --- | --- |
| Task | Task |
| **DELEGATE** - OUTSOURCE <br /> Urgent but Not Important | **AVOID** - ELIMINATE <br /> Not Important & Not Urgent |
| Task | Task |
