# Conference Session Notes

**Conference:** 
**Session / Track:** 
**Speaker:** 
**Topic:** 
**Date & Time:** {{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Notes
-

## Thoughts
-

## Key-learnings / takeaways
-

## Action Items
-


