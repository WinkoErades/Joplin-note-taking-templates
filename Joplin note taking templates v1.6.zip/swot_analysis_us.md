# SWOT Analysis
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Subject
-

## Use the matrix below to do a SWOT analysis on the subject above
| **STRENGTHS** - Favourable <br /> Internal | **WEAKNESS** - Unfavourable <br /> Internal |
| --- | --- |
| Strengths? | Weaknesses? |
| **OPPORTUNITIES** - Favourable <br /> External | **THREATS** - Unfavourable <br /> External |
| Opportunities? | Threats? |

## Actions
-
