# Script - Client/Objective
Created: {{#custom_datetime}}[]YYYY[-]MM[-]DD{{/custom_datetime}}

## Target audience:
A short description of who is your audience? Why this session? What is the objective?

## Meeting:
- Date:
- Start Time:
- End Time:
- Location:

## Script
| **Time** | **Item** | **Technique** | **Who leads** |
| --- | --- | --- | --- | 
| 00:00 | Walk-in and reception  | warm welcome | name | 
| 00:00 | | | |
| 00:00 | | | |
| 00:00 | | | |
| 00:00 | Break |  |  |
| 00:00 | | | |
| 00:00 | | | |
| 00:00 | | | |
| 00:00 | Wrap-up, summarize outcomes, next steps and word of gratitude from the client about the result of the session. | Presenting | Client | 
| 00:00 | Meeting Evaluation (Tips and Tops) | Presenting | | 

## Materials Needed
-

## Tips
- 

## Tops
-

## Evaluation
-
