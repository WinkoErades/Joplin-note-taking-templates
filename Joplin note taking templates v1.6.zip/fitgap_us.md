# FIT GAP Analysis
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Goal
-

## Fit Gap - Report date: dd-mm-yyyy

| **Fit Gap #** | **Depending on** | **Priority** | **Process** | **Procedure** | **Current situation** | **Desired situation (Goal)** | **Gap** | **Action** | **Measure** | **Action holder** | **Date start** | **Scheduled date ready** | **Realized date ready** | **Status** | **Remarks** |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| *Unique Fit Gap identification number* | *The activity depends on what other activity* | *Weighting factor of the activity to be performed* | *What process is the Fit Gap related to?* | *What procedure is the Fit Gap related to?* | *How is it implemented now (IST)? Findings / bottlenecks.* | *What must be achieved (SOLL)?* | *What is the difference between IST and SOLL?* | *What activity / solution / control measure must be taken to achieve SOLL?* | *How do we know we have achieved the goal?* | *Who directs the action?* | *When will the activity start?* | *When should the action be completed?* | *When is the activity completed?* | *What is the status of the activity?* | *Additional information regarding date, status, reports, meetings, etc.* |
| FG001 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG002 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG003 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG004 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG005 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG006 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG007 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG008 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG009 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| FG010 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
