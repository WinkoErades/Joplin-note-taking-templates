# Meeting Title
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Meeting Details
- Date and Time:
- Location:
- Agenda:

## Attendees
-  Present: 
-  Not Present: 

## Announcements
-

## Status of Old Action Items
- 

## Summary
-

## Next Meeting
- Date and Time:
- Location:
- Agenda:
- Notes:
 
