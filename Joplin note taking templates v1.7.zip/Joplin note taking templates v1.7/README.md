# Joplin note taking templates
Joplin templates make it easier for you to quickly create new notes within the **Joplin desktop app**.
You can also insert templates into existing notes.

## Joplin
Joplin is a great, free and easy to use open source note taking and to-do application. 
Created notes can be synchronised with multi platform clients across various cloud services.

## How to use Joplin templates
- Please read the Joplin documents about using templates.

## Downloading Joplin note taking templates
You can download the templates here:
https://github.com/WinkoErades/Joplin-note-taking-templates/releases/

Have fun!

Winko
