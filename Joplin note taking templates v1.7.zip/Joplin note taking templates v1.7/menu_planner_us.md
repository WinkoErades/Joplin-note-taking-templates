# Menu Planner and Grocery List {{#custom_datetime}}[]YYYY[ WK ]w[]{{/custom_datetime}}

| | | | | | | | | | | | |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | 
| **Day** | **What To Eat** | **Produce** | **Cans and Jars** | **Dairy/Cheeses** | **Breads, Grains, Pastas**   |  **Meat, Poultry, Fish** | **Baking Supplies** | **Beverages** | **Other Shelf Items** | **Frozen** | **Miscellaneous** |
| **Sunday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Monday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Tuesday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Wednesday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Thursday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Friday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |
| **Saturday** | | | | | | | | | | | |
|B: | | | | | | | | | | | |
|L: | | | | | | | | | | | |
|D: | | | | | | | | | | | |

