# SIPOC - Process Title
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Goal
-

## SIPOC

| **Supplier** | **Input** | **Process** | **Output** | **Customer** |
|---|---|---|---|---|
||||||
||||||
||||||
||||||
||||||
||||||
||||||
||||||
||||||
||||||
