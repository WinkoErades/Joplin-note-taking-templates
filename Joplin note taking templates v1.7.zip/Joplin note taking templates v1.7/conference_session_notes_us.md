# Conference Session Notes

**Conference:** 

**Session / Track:** 

**Speaker:** 

**Topic:** 

**Date & Time:** {{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Notes
- Take session notes here.

## Thoughts
- Most important thoughts of this session.

## Key-learnings / takeaways
- Summarize the main points of this session.

## Action Items
- What actions to undertake as a result of this session.


