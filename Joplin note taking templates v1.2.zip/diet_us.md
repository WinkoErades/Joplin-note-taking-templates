**{{#custom_datetime}}[]YYYY[ WK ]w[]{{/custom_datetime}}**

<br />

| **Day** | **Breakfast** | **Inbetween** | **Lunch** | **Inbetween** | **Supper** | **Inbetween** | **Particularities** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Mon.** |     |     |     |     |     |     |     |
| **Tues.** |     |     |     |     |     |     |     |
| **Wed.** |     |     |     |     |     |     |     |
| **Thurs.** |     |     |     |     |     |     |     |
| **Fri.** |     |     |     |     |     |     |     |
| **Sat.** |     |     |     |     |     |     |     |
| **Sun.** |     |     |     |     |     |     |     |

<br />

| **Movement** | **Mon.** | **Tues.** | **Wed.** | **Thurs.** | **Fri.** | **Sat.** | **Sun.** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Steps** |     |     |     |     |     |     |     |

<br />

| **Sleep** | **Mon.** | **Tues.** | **Wed.** | **Thurs.** | **Fri.** | **Sat.** | **Sun.** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Hours** |     |     |     |     |     |     |     |
