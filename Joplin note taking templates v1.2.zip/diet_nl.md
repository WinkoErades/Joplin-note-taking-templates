**{{#custom_datetime}}[]YYYY[ WK ]w[]{{/custom_datetime}}**

<br />

| **Dag** | **Ontbijt** | **Tussendoor** | **Lunch** | **Tussendoor** | **Avondeten** | **Tussendoor** | **Bijzonderheden** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Ma** |     |     |     |     |     |     |     |
| **Di** |     |     |     |     |     |     |     |
| **Wo** |     |     |     |     |     |     |     |
| **Do** |     |     |     |     |     |     |     |
| **Vr** |     |     |     |     |     |     |     |
| **Za** |     |     |     |     |     |     |     |
| **Zo** |     |     |     |     |     |     |     |

<br />

| **Beweging** | **ma** | **di** | **wo** | **do** | **vr** | **za** | **zo** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Stappen** |     |     |     |     |     |     |     |

<br />

| **Slaap** | **ma** | **di** | **wo** | **do** | **vr** | **za** | **zo** |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **Uren** |     |     |     |     |     |     |     |
