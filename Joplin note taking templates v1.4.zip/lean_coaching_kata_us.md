# LEAN - Coaching Kata {{#custom_datetime}}[]YYYY[ WK ]w[]{{/custom_datetime}}
{{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Learner
-

## Coach
-

## Kata
| **Step** | **Question** | **Answer** |
| --- | --- | ---|
| 0 | What is the challenge? | |
| 1 | What is the target condition? | |
| 2 | What is the actual condition now? | |
| 2a | What was your last step? | |
| 2b | What did you expect? | |
| 2c | What actually happened? | |
| 2d | What did you learn?| |
| 3 | What obstacles do you think are preventing you from reaching the target condition? Which one are you addressing now? | |
| 4 | What is your next step? What do you expect? | |
| 5 | When can we go and see what we have learnt from taking that step? | |

## Remarks
-

## Next Kata
- Date and Time:
- Location:


