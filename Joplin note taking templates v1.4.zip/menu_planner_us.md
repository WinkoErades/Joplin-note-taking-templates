# Menu Planner and Grocery List {{#custom_datetime}}[]YYYY[ WK ]w[]{{/custom_datetime}}

| **What To Eat** | **To Buy** ||
| --- | --- | --- | 
| **Sunday** | **Produce** | **Cans and Jars** |
|B: | | |
|L: | | |
|D: | | |
| **Monday** |     |     |
|B: | | |
|L: | **Dairy/Cheeses** | **Breads, Grains, Pastas** |
|D: | | |
| **Tuesday** |     |     |
|B: | | |
|L: | | |
|D: | | |
| **Wednesday** | **Meat, Poultry, Fish** | **Baking Supplies** |
|B: | | |
|L: | | |
|D: | | |
| **Thursday** |     |     |
|B: | | |
|L: | **Beverages** | **Other Shelf Items** |
|D: | | |
| **Friday** |     |     |     |
|B: | | |
|L: | | |
|D: | | |
| **Saturday** | **Frozen**    | **Miscellaneous**   |
|B: | | |
|L: | | |
|D: | | |

