# KWL Chart - Research Subject
Created: {{#custom_datetime}}[]YYYY[-]MM[-]DD[ ]HH[:]mm[]{{/custom_datetime}}

## Short description of the research subject
-

Before you begin your research, list details in the first two columns. Fill in the last column after completing your research.

| What do you **Know** about the topic? | What do you **Want** to know? | What did you **Learn**? |
| --- | --- | --- | 
||||

## Questions
- What questions do you have after this research?
-
 
## To study
- Which part of the curriculum do you need to study further to know **what you want to know**?
- 
