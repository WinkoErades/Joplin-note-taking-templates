# Name of recipe

||**Time**|
| --- | --- | 
|**Prep Time**||
|**Cook Time**||

## Ingredients
| | Serving 1 | Serving 2 | 
| --- | --- | --- | 
| **Ingredients** | **Qty/Wt/Vol** | **Qty/Wt/Vol** |
||||


## Directions
- Step 1

## Serving
- Serving 1

## Notes
- Notes 1
